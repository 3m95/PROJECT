package com.example.wavesoffood;

import androidx.fragment.app.Fragment;

public class CartFragment extends Fragment {
}
