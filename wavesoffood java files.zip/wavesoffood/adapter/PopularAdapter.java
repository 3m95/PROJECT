package com.example.wavesoffood.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.wavesoffood.Fragment.HomeFragment;
import com.example.wavesoffood.R;

public class PopularAdapter extends ArrayAdapter<String> {
   private final String[] ItemName;
    private final int[] imgId;
   private final String[] price;
   Context context;
    public PopularAdapter(Context context, String[] name, String[] prz, int[] img)
    {  super(context, R.layout.popular_item, name);
        this.ItemName=name;
        this.imgId=img;
        this.price=prz;
        this.context=context;
    }

public View getView(int position, View convertView, ViewGroup Parent)
{
    View listViewItem=convertView;
    LayoutInflater inflator=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    listViewItem=inflator.inflate(R.layout.popular_item,null);
    ImageView image = listViewItem.findViewById(R.id.popular_imgs);
    TextView name = listViewItem.findViewById(R.id.text_view1);
    TextView Price = listViewItem.findViewById(R.id.popular_price);

    image.setImageResource(imgId[position]);
    name.setText(ItemName[position]);
    Price.setText(price[position]);

    return listViewItem;


}


}
