package com.example.wavesoffood.Fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.example.wavesoffood.R;
import com.example.wavesoffood.adapter.PopularAdapter;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;
import java.util.List;

public class  HomeFragment extends Fragment {
    int[] Images={R.drawable.back1, R.drawable.back2,R.drawable.background};
    String[] Name={"Burger", "Sandwich", "momo"};
    String[] Price={"Rs 120", "Rs 200", "Rs 300"};
    private  ListView list;
    private ViewPager2 imageSlider;
    private TabLayout tabLayout;
    private Handler sliderHandler;
    private Runnable sliderRunnable;
    private final int SLIDE_DELAY = 3000; // 3 seconds

    public HomeFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        imageSlider = view.findViewById(R.id.image_slider);
        tabLayout = view.findViewById(R.id.tab_layout);
        list=view.findViewById(R.id.list_view1);


        List<Integer> imageList = new ArrayList<>();
        imageList.add(R.drawable.back1);
        imageList.add(R.drawable.back2);
        imageList.add(R.drawable.background);

        ImageSliderAdapter adapter = new ImageSliderAdapter(getContext(), imageList);
        imageSlider.setAdapter(adapter);

        PopularAdapter adapter2=new PopularAdapter(getContext(),Name,Price,Images);
        list.setAdapter(adapter2);

        // Setting up TabLayout with ViewPager2
        new TabLayoutMediator(tabLayout, imageSlider,
                (tab, position) -> tab.setText("Image " + (position + 1))
        ).attach();

        // Auto-slide functionality
        sliderHandler = new Handler(Looper.getMainLooper());
        sliderRunnable = new Runnable() {
            @Override
            public void run() {
                int nextItem = (imageSlider.getCurrentItem() + 1) % imageList.size();
                imageSlider.setCurrentItem(nextItem, true);
                sliderHandler.postDelayed(this, SLIDE_DELAY);
            }
        };
        sliderHandler.postDelayed(sliderRunnable, SLIDE_DELAY);

        return view;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (sliderHandler != null && sliderRunnable != null) {
            sliderHandler.removeCallbacks(sliderRunnable);
        }
    }


}
