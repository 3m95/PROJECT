package com.example.wavesoffood.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.wavesoffood.adapter.CartAdapter;
import com.example.wavesoffood.Models.CartItem;
import com.example.wavesoffood.R;

import java.util.ArrayList;
import java.util.List;

public class CartFragment extends Fragment {
    private RecyclerView recyclerView;
    private CartAdapter cartAdapter;
    private List<CartItem> cartItemList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view;
        view = inflater.inflate(R.layout.fragment_cart, container, false);

        recyclerView = view.findViewById(R.id.cart_listview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Initialize cart item list and adapter
        cartItemList = new ArrayList<>();
        cartItemList.add(new CartItem("Item 1", 2, 9.99,R.drawable.cart_item1));
        cartItemList.add(new CartItem("Item 2", 1, 19.99,R.drawable.cart_item2));
        cartItemList.add(new CartItem("Item 3", 3, 4.99,R.drawable.cart_item3));

        cartAdapter = new CartAdapter(getContext(), cartItemList);
        recyclerView.setAdapter(cartAdapter);

        return view;
    }
}

