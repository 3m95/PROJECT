package com.example.wavesoffood;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DoctorDetailsActivity extends AppCompatActivity {
    TextView tv;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        btn=findViewById(R.id.buttonDDback);
        tv=findViewById(R.id.defaulttext);
        Intent it=getIntent();
        String title= it.getStringExtra("title ");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(DoctorDetailsActivity.this, FindDoctorActivity.class);

            }
        });

    }
}