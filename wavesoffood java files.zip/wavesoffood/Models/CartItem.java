package com.example.wavesoffood.Models;

public class CartItem {
    private String itemName;
    private int quantity;
    private double price;
    private int imageResource; // Resource ID for the item's image

    public CartItem(String itemName, int quantity, double price, int imageResource) {
        this.itemName = itemName;
        this.quantity = quantity;
        this.price = price;
        this.imageResource = imageResource;
    }

    public CartItem(String itemName, int quantity, double price) {
    }

    public String getItemName() {
        return itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getPrice() {
        return price;
    }

    public int getImageResource() {
        return imageResource;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}

