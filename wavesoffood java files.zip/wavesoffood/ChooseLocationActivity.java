package com.example.wavesoffood;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

import androidx.appcompat.app.AppCompatActivity;

public class ChooseLocationActivity extends AppCompatActivity {
       AutoCompleteTextView listview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_location);
        String[] LocationList={"Islamabad","Rawalpindi","Lahore", "Karachi","Murree"};
        listview=findViewById(R.id.listOfLocation);
        ArrayAdapter adapter=new ArrayAdapter(this, android.R.layout.simple_list_item_1,LocationList);
        listview.setAdapter(adapter);


    }
}