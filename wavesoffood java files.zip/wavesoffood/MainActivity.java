package com.example.wavesoffood;

import android.os.Bundle;
import android.view.MenuItem;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.example.wavesoffood.Fragment.CartFragment;
import  com.example.wavesoffood.Fragment.HistoryFragment;
import com.example.wavesoffood.Fragment.HomeFragment;
import com.example.wavesoffood.Fragment.ProfileFragment;
import com.example.wavesoffood.Fragment.SearchFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);

        // Set default fragment
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new HomeFragment()).commit();
        }

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectedFragment = null;
                switch (item.getItemId()) {
                    case R.id.homeFragment:
                        selectedFragment = new HomeFragment();
                        break;
                    case R.id.historyFragment:
                        selectedFragment = new HistoryFragment();
                        break;

                    case R.id.cartFragment:
                        selectedFragment = new CartFragment();
                        break;

                    case R.id.profileFragment:
                        selectedFragment = new ProfileFragment();
                        break;

                    case R.id.searchFragment:
                        selectedFragment = new SearchFragment();
                        break;
                }

                if (selectedFragment != null) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, selectedFragment).commit();
                }

                return true;
            }
        });



    }
}